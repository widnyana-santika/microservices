package com.idpuwid.authentication;

import org.springframework.data.jpa.repository.JpaRepository;

//public interface RoleRepository extends JpaRepository<AppRole, Long> {
//    AppRole findByRoleName(String roleName);
//}



public interface RoleRepository {
}