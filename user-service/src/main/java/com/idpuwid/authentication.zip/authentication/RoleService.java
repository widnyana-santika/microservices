package com.idpuwid.authentication;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@Slf4j
public class RoleService {

    private RoleRepository repository;

    public RoleService(RoleRepository repository)
    {
        this.repository = repository;
    }
    AppRole createRole(AppRole role){
        log.info("Saving new role: {}", role);
//        return repository.save(role);
        return role;
    }

    AppRole getRoleByRoleName(String roleName){
//        return repository.findByRoleName(roleName);
        return null;
    }
}
