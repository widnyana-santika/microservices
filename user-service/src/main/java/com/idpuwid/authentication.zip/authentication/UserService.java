package com.idpuwid.authentication;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@Slf4j
@EnableAutoConfiguration
public class UserService {

    private UserRepository repository;

    private RoleService roleService;

    @Autowired
    public UserService(UserRepository repository, RoleService roleService){
        this.repository = repository;
        this.roleService = roleService;
    }

    public AppUser createUser(AppUser user){
        log.info("Saving new user: {}", user);
//        return repository.save(user);
        return null;
    }

    public void addRoleToUser(String username, String roleName){
        log.info("Adding role {} to user {}", roleName, username);
//        AppRole role = roleService.getRoleByRoleName(roleName);
        AppUser user = getUserByUsername(username);
//        user.getRoles().add(role);
    }

    public List<AppUser> getUsers(){
//        return repository.findAll();
        return null;
    }
    public AppUser getUserByUsername(String username){
        log.info("Fetching user {}", username);
//        return repository.findByUsername(username);
        return null;
    }
}
